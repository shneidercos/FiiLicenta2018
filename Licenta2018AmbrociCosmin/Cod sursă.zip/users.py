import socket
import getpass
import random
from time import sleep
import errno
import labmath
import pyaes
import lepl.apps.rfc3696
import math
from decimal import Decimal

modulo_number = 0
quadratic_non_residue = 0
prime_g = 0
e_mail = ''
password = ''
my_ip = str(socket.gethostbyname(socket.gethostname()))
my_port = random.randint(4000, 5000)
online_list = []


def string_to_number(string):
    number = []
    for index in string:
        number.append(ord(index))
    rez = 1
    for index in number:
        rez = rez + index
    rez = rez / len(string)
    return int(math.sqrt(rez))


def encript(number_password, hash_identity):
    global modulo_number
    tuples_list = []
    binary_number_password = str(bin(number_password)).replace('b', '')

    for index in binary_number_password:

        while True:
            t1 = random.randint(1, modulo_number - 1)
            jacobi1 = labmath.jacobi(t1, modulo_number)
            if jacobi1 == 1 and int(index) == 1:

                while True:
                    t2 = random.randint(1, modulo_number - 1)
                    if t1 == t2:
                        break
                    jacobi2 = labmath.jacobi(t2, modulo_number)
                    if jacobi2 == 1 and int(index) == 1:
                        reverse_t1 = labmath.modinv(t1, modulo_number)
                        reverse_t2 = labmath.modinv(t2, modulo_number)
                        first_part_tuple = (t1 + hash_identity * reverse_t1) % modulo_number
                        second_part_tuple = (t2 + hash_identity * reverse_t2) % modulo_number
                        tuples_list.append((first_part_tuple, second_part_tuple))
                        break
                break
            if jacobi1 == -1 and int(index) == 0:

                while True:
                    t2 = random.randint(1, modulo_number - 1)
                    if t1 == t2:
                        break
                    jacobi2 = labmath.jacobi(t2, modulo_number)
                    if jacobi2 == -1 and int(index) == 0:
                        reverse_t1 = labmath.modinv(t1, modulo_number)
                        reverse_t2 = labmath.modinv(t2, modulo_number)
                        first_part_tuple = (t1 + int(Decimal(hash_identity * reverse_t1))) % modulo_number
                        second_part_tuple = (t2 + hash_identity * reverse_t2) % modulo_number
                        tuples_list.append((first_part_tuple, second_part_tuple))
                        break
                break
    return tuples_list


def decript(tuple_list, hash_identity):
    decripted_password = ''
    global modulo_number

    square_root, mode = genarator_send_optin("compute_square", hash_identity)

    if mode == 1:
        for index in tuple_list:

            aux = labmath.jacobi(int(int(index[0]) + (2 * square_root)), modulo_number)
            if aux == 1:
                decripted_password += str(aux)
            elif aux == -1:
                decripted_password += '0'
    else:
        for index in tuple_list:

            aux = labmath.jacobi(int(int(index[1]) + (2 * square_root)), modulo_number)
            if aux == 1:
                decripted_password += str(aux)
            elif aux == -1:
                decripted_password += '0'

    return int(decripted_password, 2)


def translate(string):
    variable = string[1:-1]
    variable = variable.split(", ")
    variable[2] = str(variable[2]) + ',' + str(variable[3])
    variable.pop()

    variable[0] = int(variable[0])
    variable[1] = variable[1].replace("'", "")
    variable[2] = variable[2].replace('"', "")
    aux = variable[2][1:-1]
    aux = aux.split(',')
    aux[0] = aux[0].replace("'", '')

    variable[2] = (aux[0], int(aux[1]))
    return variable


def connection_to_generator():
    global modulo_number, quadratic_non_residue, prime_g, e_mail, password, my_port, my_ip, online_list
    generator_ip = '127.0.0.1'
    generator_port = 5000

    mySocket = socket.socket()

    try:
        mySocket.connect((generator_ip, generator_port))
    except socket.error as error:
        if error.errno == errno.ECONNREFUSED:
            print("Server is offline. Try again later.")
            exit(0)

    mySocket.send("register".encode())
    mesage = mySocket.recv(1024).decode()

    mesage_split = mesage.split('#')

    modulo_number = int(mesage_split[0])
    quadratic_non_residue = int(mesage_split[1])
    prime_g = int(mesage_split[2])

    while True:
        e_mail = input("Insert e-mail:")
        test = lepl.apps.rfc3696.Email()
        if str(test(e_mail)) == "False":
            print("Wrong e-mail. Try again.")
        else:
            mesage_to_send = e_mail + "#('" + my_ip + "', " + str(my_port) + ")"
            mySocket.send(mesage_to_send.encode())
            confirmation = mySocket.recv(1204).decode()
            if confirmation == "ok":
                break
            if confirmation == "fraud":
                print("E-mail already in use")

    sleep(0.1)
    online_list_string = mySocket.recv(1024).decode()

    while online_list_string != '[]':
        online_list.append(translate(online_list_string))
        online_list_string = mySocket.recv(1024).decode()

    while True:
        print("Note: password must have length 4 to 10 characters")
        password = getpass.getpass(prompt='Insert password: ')
        if 4 <= len(password) <= 10:
            break
        else:
            print("Wrong length.")
    mySocket.close()


def aes_32(string):
    while len(string) > 32:
        half = int(len(string) / 2)
        first_half = string[0:half]
        second_half = string[half:]
        string = str(int(first_half) + int(second_half))

    while len(string) != 32:
        string += '0'

    return string


def translate_tuple(string_tuple):
    string_tuple = string_tuple[1:-1]
    aux = string_tuple.split(",")

    return (aux[0], aux[1])


def encrypt_aes(key, mesage):
    key = key.encode("latin-1")
    function = pyaes.AESModeOfOperationCTR(key)
    encrypted_mesage = function.encrypt(mesage)
    return encrypted_mesage


def decrypt_aes(key, dates):
    key = key.encode("latin-1")
    function = pyaes.AESModeOfOperationCTR(key)
    decrypted_mesage = function.decrypt(dates).decode('latin-1')
    return decrypted_mesage


def listening():
    global my_ip, my_port

    print("Wait until someone contact you")

    mySocket = socket.socket()
    mySocket.bind((my_ip, my_port))
    mySocket.listen(10)
    conn, addr = mySocket.accept()
    person = conn.recv(1024).decode()
    genarator_send_optin("bussy")

    number_identity = conn.recv(1024).decode()
    encoded_tuple = []
    while True:
        string_tuple = conn.recv(1024).decode()
        if string_tuple == "[]":
            break
        else:
            encoded_tuple.append(translate_tuple(string_tuple))

    decripted_mesage = decript(encoded_tuple, number_identity)

    # incepe encript

    conn.send(e_mail.encode())

    password_number = string_to_number(password)

    numder_identity = genarator_send_optin("compute_identity", person)

    conn.send(numder_identity.encode())

    sleep(0.2)

    number_to_encript = prime_g ** password_number

    encripted_tuple = encript(number_to_encript, int(numder_identity))

    for index in encripted_tuple:
        conn.send(str(index).encode())
        sleep(0.1)
    conn.send("[]".encode())

    aes_password_brute = decripted_mesage ** password_number

    aes_short = aes_32(str(aes_password_brute))

    print("aes short=", aes_short)

    print(person + ': connected')
    message="connected"
    message_encrypted = encrypt_aes(aes_short, message)
    conn.send(message_encrypted)

    while True:
        message_encrypted = conn.recv(1024)
        message_decrypted=decrypt_aes(aes_short,message_encrypted)
        if message_decrypted == "close chat":
            print("Chat was been closed")
            break
        print(person + ':', message_decrypted)
        send_message = input("Write message:")
        send_message_encrypted=encrypt_aes(aes_short,send_message)
        conn.send(send_message_encrypted)
        if send_message == "close chat":
            break

    genarator_send_optin("not bussy")


def connecting_to(person):
    print("You are conecting with:", person)
    global online_list, prime_g

    for index in online_list:
        if index[1] == person:
            person_ip = index[2][0]
            person_port = index[2][1]
            break

    mySocket = socket.socket()
    try:
        mySocket.connect((person_ip, person_port))
    except socket.error as error:
        if error.errno == errno.ECONNREFUSED:
            print("Can't connect to", person, ". Try again later")
            genarator_send_optin("not bussy")
            actions()
            exit(0)
    mySocket.send(e_mail.encode())

    password_number = string_to_number(password)

    numder_identity = genarator_send_optin("compute_identity", person)

    mySocket.send(numder_identity.encode())
    sleep(0.2)

    number_to_encript = prime_g ** password_number

    encripted_tuple = encript(number_to_encript, int(numder_identity))

    for index in encripted_tuple:
        mySocket.send(str(index).encode())
        sleep(0.1)
    mySocket.send("[]".encode())

    # incepe decript

    person = mySocket.recv(1024).decode()
    sleep(0.1)
    number_identity = mySocket.recv(1024).decode()

    encoded_tuple = []
    while True:
        string_tuple = mySocket.recv(1024).decode()
        if string_tuple == "[]":
            break
        else:
            encoded_tuple.append(translate_tuple(string_tuple))

    decripted_mesage = decript(encoded_tuple, number_identity)

    aes_password_brute = decripted_mesage ** password_number

    aes_short = aes_32(str(aes_password_brute))

    print("aes short=", aes_short)

    while True:
        message_encrypted = mySocket.recv(1024)
        message_decrypted = decrypt_aes(aes_short, message_encrypted)
        if message_decrypted == "close chat":
            print("Chat was been closed")
            break
        print(person + ':', message_decrypted)
        send_message = input("Write message:")
        send_message_encrypted = encrypt_aes(aes_short, send_message)
        mySocket.send(send_message_encrypted)
        if send_message == "close chat":
            break


def refresh_online_list():
    global online_list

    generator_ip = '127.0.0.1'
    generator_port = 5000

    online_list = []
    mySocket = socket.socket()
    mySocket.connect((generator_ip, generator_port))

    mySocket.send("refresh_list".encode())

    online_list_string = mySocket.recv(1024).decode()

    while online_list_string != '[]':
        online_list.append(translate(online_list_string))
        online_list_string = mySocket.recv(1024).decode()

    mySocket.close()


def genarator_send_optin(option, person=0):
    global e_mail

    generator_ip = '127.0.0.1'
    generator_port = 5000

    mySocket = socket.socket()
    mySocket.connect((generator_ip, generator_port))

    mySocket.send(option.encode())
    sleep(0.1)
    if option == "compute_identity":
        mySocket.send(person.encode())
        number_identity = mySocket.recv(1024).decode()
        mySocket.close()
        return number_identity
    elif option == "compute_square":
        mySocket.send(person.encode())
        square_root_mode = mySocket.recv(1024).decode()
        mySocket.close()
        answer = square_root_mode.split("#")
        return int(answer[0]), int(answer[1])
    else:
        mySocket.send(e_mail.encode())

    mySocket.close()
    if option == "exit":
        exit(0)


def print_list():
    global online_list
    counter = 0
    for index in online_list:
        name = index[1]
        counter += 1
        print(str(counter) + '.', name)


def actions():
    global online_list, e_mail

    while True:
        refresh_online_list()
        print_list()
        talk = input("\n\nDo  you want to contact someone?(Yes\\No)\n")
        flag1 = 0
        if talk.lower() == "yes":
            while True:
                person_to_talk = input(
                    "\nEnter the name of the person you want to talk to or use \"return\" to return to previous menu:\t")
                if person_to_talk == "return":
                    flag1 = 1
                    break
                if person_to_talk != e_mail:
                    found = 0
                    refresh_online_list()
                    for index in online_list:
                        if index[1] == person_to_talk:
                            found = 1

                    if found == 1:
                        break
                    else:
                        print("You entered a misspelled name. Try again")
                        refresh_online_list()
                        print_list()
                else:
                    print("You can't connect to yourself. Try a valid user from list ")
                    print("\n")
                    refresh_online_list()
                    print_list()
            if flag1 == 0:
                genarator_send_optin("bussy")
                connecting_to(person_to_talk)
                genarator_send_optin("not bussy")
                print("\n")
                # refresh_online_list()
        elif talk.lower() == "no":
            while True:
                choice = input("\n\nDo  you want to exit or wait other people to contact you?(Exit\\Contact)\n")
                if choice.lower() == "exit":
                    genarator_send_optin("exit")
                elif choice.lower() == "contact":
                    listening()
                    break
                else:
                    print("Wrong command. Try again.")
            print("\n")
            # refresh_online_list()
        else:
            print("Wrong command. Try again.")
            print("\n")
            # refresh_online_list()


connection_to_generator()
actions()
