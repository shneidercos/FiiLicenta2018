import socket  # Import socket module
import _thread
import threading
import random
import labmath
from time import sleep
import errno
import datetime
import hashlib

host = "127.0.0.1"
port = 5000
mySocket = socket.socket()
mySocket.bind((host, port))
mySocket.listen(10)
online_users = []
bussy_users = []
time_online_users = []


def square_root_function(hash_identity):
    global prime_p, prime_q, quadratic_non_residue
    jacobiAP = labmath.jacobi(hash_identity, prime_p)

    if jacobiAP == 1:
        quadraticAP = labmath.sqrtmod_prime(hash_identity, prime_p)
        quadraticAQ = labmath.sqrtmod_prime(hash_identity, prime_q)
        quadraticAN = labmath.crt((quadraticAP, quadraticAQ), (prime_p, prime_q))
        return quadraticAN, 1

    if jacobiAP == -1:
        quadraticAP = labmath.sqrtmod_prime(quadratic_non_residue * hash_identity, prime_p)
        quadraticAQ = labmath.sqrtmod_prime(quadratic_non_residue * hash_identity, prime_q)
        quadraticAN = labmath.crt((quadraticAP, quadraticAQ), (prime_p, prime_q))
        return quadraticAN, 2


def generate_prime_number(bits):
    while True:
        random_number = random.randrange(2 ** (bits-1), (2 ** bits))
        print("rand=",random_number)
        prime_number = labmath.prevprime(random_number)  # first prime number lower than random_number
        if str(prime_number) != "None":
            return prime_number


def generate_quadratic_non_residue():
    global prime_p, prime_q, modulo_number
    while True:
        random_number = random.randint(0, modulo_number)
        if labmath.jacobi(random_number, prime_p) == labmath.jacobi(random_number, prime_q) == -1:
            return random_number


prime_p = generate_prime_number(128)
prime_q = generate_prime_number(128)
prime_g = generate_prime_number(8)
modulo_number = prime_p * prime_q
quadratic_non_residue = generate_quadratic_non_residue()
identitys_list = []


def translate(string):
    global online_users
    variable = string.split("#")
    variable[0] = variable[0].replace("'", "")
    variable[1] = variable[1].replace('"', "")

    aux = variable[1][1:-1]
    aux = aux.split(',')
    aux[0] = aux[0].replace("'", '')

    variable[1] = (aux[0], int(aux[1]))
    return [len(online_users), variable[0], variable[1]]


def session(conn, addr):
    global modulo_number, quadratic_non_residue, prime_g, online_users, bussy_users, time_online_users

    option = conn.recv(1024).decode()

    print(option)
    if option == "register":
        conn.send((str(modulo_number) + '#' + str(quadratic_non_residue) + '#' + str(prime_g)).encode('utf8'))

        while True:
            fraud = 0
            try:
                identity = (conn.recv(1024).decode())
            except socket.error as error:
                if error.errno == errno.ECONNRESET:
                    print("Connection aborted by user")
                    exit(0)

            separator_position = identity.find("#")
            for index in online_users:
                if index[1] == identity[:separator_position]:
                    fraud = 1
            if fraud == 1:
                conn.send("fraud".encode())
            else:
                conn.send("ok".encode())
                break

        online_users.append(translate(identity))
        time_online_users.append((online_users[len(online_users) - 1][0], datetime.datetime.now()))

        for index in online_users:
            print(index)

        for index in time_online_users:
            print(index)

        for index in online_users:
            if index[1] not in bussy_users:
                conn.send(str(index).encode())
                sleep(0.5)
            if index == online_users[len(online_users) - 1]:
                conn.send("[]".encode())
        conn.close()

    elif option == "compute_square":
        number_identity = conn.recv(1024).decode()
        root,mode=square_root_function(int(number_identity))
        conn.send((str(root)+"#"+str(mode)).encode())

    elif option == "compute_identity":
        identity=conn.recv(1024).decode()
        hash_indentity = int(str(hashlib.sha256(str(identity).encode()).hexdigest()), 16)  # hash peste ID
        while True:
            if labmath.jacobi(hash_indentity, modulo_number) == 1 and labmath.jacobi(
                    hash_indentity, prime_p) == labmath.jacobi(hash_indentity, prime_q) == abs(1):
                break
            else:
                hash_indentity = int(str(hashlib.sha256(str(hash_indentity).encode()).hexdigest()), 16)

        conn.send(str(hash_indentity).encode())
        conn.close()

    elif option == "refresh_list":

        for index in online_users:
            if index[1] not in bussy_users:
                conn.send(str(index).encode())
                sleep(0.1)
            if index == online_users[len(online_users) - 1]:
                conn.send("[]".encode())
        conn.close()

    elif option == "exit":
        name = conn.recv(1024).decode()
        position = -1
        index = 0
        while index < len(online_users):
            person = online_users[index]
            if person[1] == name:
                online_users.pop(index)
                time_online_users.pop(index)
                position = index
            if len(online_users) == 0:
                break
            if position > -1 and index < len(online_users):
                online_users[index][0] = online_users[index][0] - 1
            index += 1
        conn.close()

    elif option == "bussy":
        name = conn.recv(1024).decode()
        bussy_users.append(name)
        conn.close()

    elif option == "not bussy":
        list = bussy_users
        name = conn.recv(1024).decode()
        index = 0

        while index < len(bussy_users):
            if bussy_users[index] == name:
                position = 0
                for info1 in online_users:
                    if info1[1] == name:
                        position = info1[0]
                        break
                for info2 in time_online_users:
                    if info2[0] == position:
                        time_online_users.append((info2[0], datetime.datetime.now()))
                        time_online_users.remove(info2)
                bussy_users.pop(index)
                index -= 1
            index += 1
        print(bussy_users)
        conn.close()


def remove_voids():
    global online_users

    counter = 0
    for index in online_users:
        counter += 1
        if index[0] != counter:
            index[0] = counter


def search_active_users():
    global online_users, bussy_users, time_online_users

    list1 = online_users,
    list2 = time_online_users
    print("search_active_users")
    index = 0
    while index < len(online_users):
        flag = 0
        mySocket = socket.socket()
        info_to_verify = online_users[index]
        for aux in time_online_users:
            if info_to_verify[0] == aux[0]:
                info_about_time_person = aux
                flag = 1
                break
        if flag:
            time_past = datetime.datetime.now() - info_about_time_person[1]
            test = divmod(time_past.total_seconds(), 60)[0]
            if info_to_verify[1] not in bussy_users and test >= 2:
                try:
                    mySocket.connect(info_to_verify[2])
                except socket.error as error:
                    if error.errno == errno.ECONNREFUSED:
                        online_users.pop(index)
                        time_online_users.remove(info_about_time_person)
                        remove_voids()
                        print("info removed")
        mySocket.close()
        index += 1


while True:
    threading.Timer(120, search_active_users).start()
    conn, addr = mySocket.accept()
    _thread.start_new_thread(session, (conn, addr))
